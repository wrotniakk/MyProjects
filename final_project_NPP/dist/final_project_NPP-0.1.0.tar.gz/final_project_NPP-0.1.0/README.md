This is the final assignment for the subject NPP at MIMUW

The IMDB movie data can be found under the link:
https://datasets.imdbws.com/

The description is found here:
https://developer.imdb.com/non-commercial-datasets/

